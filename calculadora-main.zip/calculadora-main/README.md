# Calculadora com HTML, CSS e JavaScript
Vídeo da calculadora no canal -> https://www.youtube.com/watch?v=42TShjXR0m0

<img src="https://1.bp.blogspot.com/-TfCAA8mlc6A/YCVAzmezLPI/AAAAAAAAAnY/Xn3pI1Pj7UstC4xFhlBnFWys3dkv-GbQACLcBGAsYHQ/s1280/calculadora.png">
